./mvnw package; & cd target; cp quizBackend-0.jar ./..; & cd ./..; & java -jar ./quizBackend-0.jar;
